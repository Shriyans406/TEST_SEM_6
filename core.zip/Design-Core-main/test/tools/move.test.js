import { Core } from '../../core/core/core.js';
import { Point } from '../../core/entities/point.js';
import { Move } from '../../core/tools/move.js';

const core = new Core();

const inputScenarios = [
  {
    desc: 'Move by point',
    inputs: [new Point(10, 0), new Point(30, 20)],
    result: new Point(40, 20),

  },
  {
    desc: 'move by negative distance',
    inputs: [new Point(10, 0), new Point(-30, -20)],
    result: new Point(-20, -20),
  },

];

test.each(inputScenarios)('Move.execute handles $desc', async (scenario) => {
  const { inputs, result } = scenario;
  const origInputManager = core.scene.inputManager;
  let callCount = 0;
  core.scene.inputManager = {
    requestInput: async () => {
      if (callCount < inputs.length) {
        const input = inputs[callCount];
        callCount++;
        return input;
      }
    },

    executeCommand: async () => { },
  };

  // clear all scene entities
  core.scene.clear();
  // create line
  const pointOne = new Point(10, 0);
  const pointTwo = new Point(20, 0);
  core.scene.addItem('Line', { points: [pointOne, pointTwo] });

  // select line
  core.scene.selectionManager.addToSelectionSet(0);

  const move = new Move();
  await move.execute();

  move.action();

  const line = core.scene.entities.get(0);

  expect(line.points[1].x).toBeCloseTo(result.x);
  expect(line.points[1].y).toBeCloseTo(result.y);

  // Restore original inputManager
  core.scene.inputManager = origInputManager;
});

test('Test Move.action', () => {
  // Add items to scene
  core.scene.clear();
  core.scene.addItem('Line', { points: [new Point(), new Point(0, 10)] });
  core.scene.addItem('Circle', { points: [new Point(), new Point(0, 10)] });
  core.scene.addItem('Polyline', { points: [new Point(), new Point(0, 10)] });
  core.scene.addItem('Arc', { points: [new Point(), new Point(0, 10), new Point(10, 0)] });
  core.scene.addItem('Rectangle', { points: [new Point(), new Point(0, 10)] });
  core.scene.addItem('Text', { points: [new Point(), new Point(0, 10)], height: 10, rotation: 0, string: 'text test' });

  // Add items to selection set
  for (let i = 0; i < core.scene.entities.count(); i++) {
    core.scene.selectionManager.addToSelectionSet(i);
  }

  /**
   * move by x = 10 y = 0
   */

  const move = new Move();

  // set base point
  move.points.push(new Point());

  // set destination point
  move.points.push(new Point(10, 0));

  // Perform move
  move.action();

  for (let i = 0; i < core.scene.entities.count(); i++) {
    expect(core.scene.entities.get(i).points[0].x).toBe(10);
    expect(core.scene.entities.get(i).points[0].y).toBe(0);
  }


  /**
   * move by x = 0 y = 10
   */
  // reset move points
  move.points = [];

  // set base point
  move.points.push(new Point());

  // set destination point
  move.points.push(new Point(0, 10));

  // Perform move
  move.action();

  for (let i = 0; i < core.scene.entities.count(); i++) {
    expect(core.scene.entities.get(i).points[0].x).toBe(10);
    expect(core.scene.entities.get(i).points[0].y).toBe(10);
  }

  /**
   * move by x = -10 y = -10
   */
  // reset move points
  move.points = [];

  // set base point
  move.points.push(new Point());

  // set destination point
  move.points.push(new Point(-10, -10));

  // Perform move
  move.action();

  for (let i = 0; i < core.scene.entities.count(); i++) {
    expect(core.scene.entities.get(i).points[0].x).toBe(0);
    expect(core.scene.entities.get(i).points[0].y).toBe(0);
  }
});
